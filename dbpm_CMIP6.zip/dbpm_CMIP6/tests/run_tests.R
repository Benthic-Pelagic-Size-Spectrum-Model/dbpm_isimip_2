library(testthat)
test_file("tests/test-dbpm_fishmip.R")
